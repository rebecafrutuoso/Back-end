/**
 * validação de formulário
 */
 
 function validar (){
	let nome = frmCadastrar.nome.value
	let email = frmCadastrar.email.value
	let idcpf = frmCadastrar.cpf.value
	let senha = frmCadastrar.senha.value
	
	if (nome === "") {
		alert ("Campos obrigatórios não foram preenchidos")	
		frmCadastrar.nome.focus()
		return false
	}	else if (idcpf=== "")  {
	    alert ("Campos obrigatórios não foram preenchidos")	
		frmCadastrar.idcpf.focus()
		return false
	}   else if (email==="")  {
	    alert ("Campos obrigatórios não foram preenchidos")	
		frmCadastrar.email.focus()
		return false
	}   else if (senha==="")  {
	    alert ("Campos obrigatórios não foram preenchidos")	
		frmCadastrar.senha.focus()
		return false
	} 	else {
		document.forms["frmCadastrar"].submit()
	  }
}