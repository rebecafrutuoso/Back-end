/**
 *Confirmação de delete de um cadastro de cliente 
 */
 
 function confirmar(cpf) {
	let resposta = confirm("Deseja deletar o cadastro desse cliente?")
	if (resposta === true){
		window.location.href = "delete?cpf=" + cpf
	}
}