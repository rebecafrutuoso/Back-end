package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAO;
import model.JavaBeans;

@WebServlet(urlPatterns = { "/Controller", "/main", "/insert", "/select", "/update", "/delete" })
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DAO dao = new DAO();
	JavaBeans cliente = new JavaBeans();
	private Object i;

	public Controller() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		if (action.equals("/main")) {
			listarCliente(request, response);
		} else if (action.equals("/insert")) {
			novoCliente(request, response);
		} else if (action.equals("/select")) {
			editarCliente(request, response);
		} else if (action.equals("/update")) {
			updateCliente(request, response);
		} else if (action.equals("/delete")) {
			removerCliente(request, response);
		} else {
			response.sendRedirect("index.html");
		}
	}

	/** listar Cliente **/
	protected void listarCliente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<JavaBeans> lista = dao.listarCliente();
		for (int i = 0; i < lista.size(); i++) {
			System.out.println(lista.get(i).getCpf());
			System.out.println(lista.get(i).getNome());
			System.out.println(lista.get(i).getEmail());
			System.out.println(lista.get(i).getSenha());
			System.out.println(lista.get(i).getTelefone());
		}
		request.setAttribute("Cliente", lista);
		RequestDispatcher rd = request.getRequestDispatcher("cadastro.jsp");
		rd.forward(request, response);
	}

	/** Novo cadastro **/
	protected void novoCliente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(request.getParameter("nome"));
		System.out.println(request.getParameter("email"));
		System.out.println(request.getParameter("cpf"));
		System.out.println(request.getParameter("telefone"));
		System.out.println(request.getParameter("senha"));

		// váriaveis JavaBeans
		cliente.setNome(request.getParameter("nome"));
		cliente.setEmail(request.getParameter("email"));
		cliente.setCpf(request.getParameter("cpf"));
		cliente.setTelefone(request.getParameter("telefone"));
		cliente.setSenha(request.getParameter("senha"));

		dao.inserirCliente(cliente);
		response.sendRedirect("main");

	}

	// Editar Cadastro//
	protected void editarCliente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/* Id do cliente que será editado */
		String Cpf = request.getParameter("cpf");
		/* Variavel JavaBeans */
		cliente.setCpf(Cpf);
		/* Executar selecionarCliente (DAO) */
		dao.selecionarCliente(cliente);
		request.setAttribute("Cpf", cliente.getCpf());
		request.setAttribute("Nome", cliente.getNome());
		request.setAttribute("Email", cliente.getEmail());
		request.setAttribute("Senha", cliente.getSenha());
		request.setAttribute("Telefone", cliente.getTelefone());

		RequestDispatcher rd = request.getRequestDispatcher("editar.jsp");
		rd.forward(request, response);

	}

	// Update Cliente//
	protected void updateCliente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		cliente.setCpf(request.getParameter("Cpf"));
		cliente.setNome(request.getParameter("Nome"));
		cliente.setEmail(request.getParameter("Email"));
		cliente.setSenha(request.getParameter("Senha"));
		cliente.setTelefone(request.getParameter("Telefone"));

		// executar alterar cliente//
		dao.alterarCadastro(cliente);
		// redirecionar para a pagina de cadastro//
		response.sendRedirect("main");
	}

	// Delete Cliente//
	protected void removerCliente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/* Verificação do cadastro a ser excluido (validador.js) */
		String cpf = request.getParameter("cpf");
		cliente.setCpf(cpf);
		dao.deletarCliente(cliente);
		// redirecionar para a pagina de cadastro//
		response.sendRedirect("main");
	}
}
