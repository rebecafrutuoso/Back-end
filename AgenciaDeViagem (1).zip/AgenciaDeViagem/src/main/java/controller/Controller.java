package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAO;
import model.JavaBeans;

@WebServlet(urlPatterns = { "/Controller", "/main", "/insert" })
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DAO dao = new DAO();
    JavaBeans cadastro  =  new JavaBeans();
	private Object i;
    
	public Controller() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		if (action.equals("/main")) {
			listarCliente(request, response);
		} else if (action.equals("/insert")) {
			novoCadastro(request, response);
		} else {
			response.sendRedirect("index.html");
		}
	}


	/** listar Cliente **/
	protected void listarCliente(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<JavaBeans> lista = dao.listarCliente ();
		for (int i=0; i <lista.size(); i++); {
			System.out.println(lista.getClass(i).getCpf());
			System.out.println(lista.getClass(i).getNome());
			System.out.println(lista.getClass(i).getEmail());
			System.out.println(lista.getClass(i).getSenha());
			System.out.println(lista.getClass(i).getTelefone());
		}
	}

	/** Novo cadastro **/
	protected void novoCadastro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(request.getParameter("nome"));
		System.out.println(request.getParameter("email"));
		System.out.println(request.getParameter("cpf"));
		System.out.println(request.getParameter("telefone"));
		System.out.println(request.getParameter("senha"));
		
		//váriaveis JavaBeans
		cadastro.setNome(request.getParameter("nome"));
		cadastro.setEmail(request.getParameter("email"));
		cadastro.setCpf(request.getParameter("cpf"));
		cadastro.setTelefone(request.getParameter("telefone"));
		cadastro.setSenha(request.getParameter("senha"));
		
		dao.inserirCliente(cadastro);
		response.sendRedirect("main");
		
		
	}

}
