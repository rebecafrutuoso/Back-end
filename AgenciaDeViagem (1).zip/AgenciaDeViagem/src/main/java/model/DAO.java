package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class DAO {
	/** Módulo de conexão **/
	// Pârâmentros de conexão
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://127.0.0.1:3306/dbagenciadeviagem?useTimezone=true&serverTimezone=UTC";
	private String user = "root";
	private String password = "frutuoso";

	private Connection conectar() {
		Connection con = null;
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, user, password);
			return con;
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

	/* CRUD Create */
	public void inserirCliente(JavaBeans cliente) {
		String create = "insert into cliente (cpf,nome,email,senha,telefone) values (?,?,?,?,?)";
		try {
			/* conexão com o banco de dados */
			Connection con = conectar();
			/* Preparar a Query para execução */
			PreparedStatement pst = con.prepareStatement(create);
			pst.setString(1, cliente.getCpf());
			pst.setString(2, cliente.getNome());
			pst.setString(3, cliente.getEmail());
			pst.setString(4, cliente.getSenha());
			pst.setString(5, cliente.getTelefone());

			/* Executar a query */
			pst.executeUpdate();
			/* Encerrar a conexão */
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* CRUD Read */
	public ArrayList<JavaBeans> listarCliente() {
		ArrayList<JavaBeans> Cliente = new ArrayList<>();
		String read = "select * from cliente order by nome";
		try {
			Connection con = conectar();
			PreparedStatement pst = con.prepareStatement(read);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				String cpf = rs.getString(1);
				String nome = rs.getString(2);
				String email = rs.getString(3);
				String senha = rs.getString(4);
				String telefone = rs.getString(5);

				Cliente.add(new JavaBeans(cpf, nome, email, senha, telefone));
			}
			con.close();
			return Cliente;
			
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}
}